#twitter : x7mii





معلومات ملف Packages بالاسفل 


Package: معرف الاداة 
Version: الاصدار
Architecture: iphoneos-arm
Maintainer: اكتب اسمك
Depends: المتطلبات 
Conflicts: التعارضات
Filename: موقع الملف
Size: 
MD5sum: 
SHA1: 
SHA256: 
Section: Tweaks
Depiction: رابط صفحة الوصف 
Name: اسم  الاداه 


 تحط سطر فراغ  تحت المعلومات كل اداة   
 
 هنا تبدا معلومات  الاداة الثانية 
